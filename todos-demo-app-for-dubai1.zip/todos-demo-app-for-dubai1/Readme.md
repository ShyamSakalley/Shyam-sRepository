# this project is created by Shyam Sakalley
# Spring Boot, MongoDB, Angular-4 Restful API Tutorial

********************************************************************************************************

This is a Fully-Fledged Todo App with Spring Boot & MongoDB in the Backend and Angular 4 in the frontend.

## Requirements

1. Java - 1.8.x

***************
2. Maven - 3.x.x

****************

3. MongoDB - 3.x.x


*********************************************************************************************************

## Steps to Setup


Build and run the backend app using maven**


cd spring-boot-backend
mvn package
java -jar target/todoapp-1.0.0.jar


Alternatively, you can run the app without packaging it using -


mvn spring-boot:run


The backend server will start at <http://localhost:8080>.

*********************************************************************************************************

Run the frontend app using npm**


cd angular4-frontend
npm install



npm start


Frontend server will run on <http://localhost:4200>


