package com.example.todoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
* The TodoappApplication program implements an application that
*  loads the  "TodoappApplication" main class.
*
* @author  Shyam Sakalley
* @version demo app
* @since   23-10-2017
*
*/
@SpringBootApplication
public class TodoappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoappApplication.class, args);
	}
}
